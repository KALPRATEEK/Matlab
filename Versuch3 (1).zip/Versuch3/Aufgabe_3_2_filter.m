clc;
clear;
close all;

%% import audio
[audio, samplerate]  = audioread("Aufgabe_3_2_rec.wav");


%% plot audio
ts = linspace(0, 10, samplerate*10);
figure;
plot(ts, audio);
xlabel('Time')
ylabel('Amplitude')

%% frequency
y = fft(audio);
n = length(audio);          % number of samples
f = (0:n-1)*(samplerate/n);     % frequency range
power = abs(y).^2/n;    % power of the DFT

figure;
area(f,power)
xlabel('Frequency')
ylabel('Power')

%% play modified audio
audio(2:2:end) = [];
audio(2:2:end) = [];
audio(2:2:end) = [];
audio(2:2:end) = [];
soundsc(audio, samplerate/8,16);

function y = sineWave(frequency, sample_rate)
    x=0:1/sample_rate:1-1/sample_rate;
    y=sin(2*pi*frequency*x);
end
