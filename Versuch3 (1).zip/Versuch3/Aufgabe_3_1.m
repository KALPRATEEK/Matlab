clc;
clear;
close all;

%% setup
freq_f1 = 1000;
freq_f2 = 4000;
freq_f3 = 5000;
freq_f4 = 20000;

samplerate = 20000;



%frequency =


%% vector

h = [1, zeros(1, 100)];

tv = linspace(0, 0.01 , 321);

t = linspace(1,100 , 20020);

hn = unknownFilter(h);
%plot(hn);

%% amplitude

y = fft(hn);

fs = samplerate;
n = length(hn);                 % number of samples
f = (0:n-1)*(samplerate/n);     % frequency range
power = abs(y).^2/n;            % power of the DFT

%plot(f,power)
xlabel('Frequency')
ylabel('Power')

%% generate sine wave


sine_f = sineWave(freq_f2, 0.01, samplerate);
sine_f_conv = conv(hn,sine_f);


%% plot sine wave
plot(sine_f);
hold on
plot(sine_f_conv);
hold off


%% functions

function y = sineWave(frequency, length_s, sample_rate)
    ts=1/sample_rate;
    t=0:ts:length_s;
    y=sin(2*pi*frequency*t);
end